medrone — Free Trial
by Zylo Instruments
====================

Thank you for trying medrone.

TRIAL TERMS
-----------
This is a 14-day free trial. No license key is required.
On first launch, your trial period begins automatically.

After 14 days, audio will mute briefly every 30 seconds
as a reminder to purchase. All features remain accessible
for continued evaluation.

To remove the trial restriction, purchase a license at:
  https://www.zyloinstruments.com/product-medrone.html

CONTENTS
--------
  Merone.exe          Standalone instrument (double-click to launch)
  Merone.vst3/        VST3 plugin folder — copy to your VST3 directory
  presets.txt         Factory presets (must remain alongside Merone.exe)
  README.txt          This file
  INSTALL.txt         Installation instructions

NOTE
----
This is a beta trial build. Please do not share this package
publicly. Feedback welcome at support@zyloinstruments.com.

SYSTEM REQUIREMENTS
-------------------
  Windows 10 or later (64-bit)
  VST3-compatible DAW (for plugin use)
  Audio interface or built-in sound card

---
(c) 2026 Zylo Instruments. All rights reserved.
